﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace TelaStart.Model
{
    class CadastroUsuario
    {
        public CadastroUsuario() { }

        public CadastroUsuario(string Usuario, string Senha)
    {
        this.Usuario = Usuario;
        this.Senha = Senha;
        }
        public string Usuario { get; set; }
        public string Senha { get; set; }
    }


}


