﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace TelaStart.Model
{
    class LoginUsuario
    {
       public LoginUsuario() { }

        public LoginUsuario(
            string Nome,
            string UsuarioLogin, 
            string Email, 
            string DataNascimento, 
            string Senha, 
            string ConfirmarSenha
            ){

            this.Nome = Nome;
            this.UsuarioLogin = UsuarioLogin;
            this.Email = Email;
            this.DataNascimento = DataNascimento;
            this.Senha = Senha;
            this.ConfirmarSenha = ConfirmarSenha;
        }

        public string Nome { get; set; }
        public string UsuarioLogin { get; set; }
        public string Email { get; set; }
        public string DataNascimento { get; set; }
        public string Senha { get; set; }
        public string ConfirmarSenha { get; set; }
    }

}
